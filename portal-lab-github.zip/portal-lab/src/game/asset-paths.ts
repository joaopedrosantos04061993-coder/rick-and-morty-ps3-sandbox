import manifest from '../../assets.lock.json'

type AssetManifest = { assets: Record<string, { path: string }> }
const assets = (manifest as AssetManifest).assets

/** Return only stable Storage paths that have been registered by the managed game-asset sync. */
export function assetUrl(projectPath: string): string {
  const path = assets[projectPath]?.path
  if (!path?.startsWith('/manus-storage/game/sha256/')) {
    throw new Error(`Asset not registered in assets.lock.json: ${projectPath}`)
  }
  return path
}
