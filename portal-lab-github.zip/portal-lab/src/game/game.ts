import * as THREE from 'three'
import { Physics, RAPIER } from '../engine/physics'
import type { Input } from '../engine/input'
import type { Renderer } from '../engine/renderer'
import type { Quality } from '../engine/save'
import { Dummies } from './dummies'
import { Player } from './player'
import { Portals } from './portals'
import { World, type PortalAnchor } from './world'

export type Mode = 'title' | 'playing' | 'paused'
export type GameStatus = { dummies: number; portals: number; connected: boolean; aiming: boolean; shots: number }

/** One offline FPS sandbox scene, with a Rapier world and linked, traversable portals. */
export class Game {
  mode: Mode = 'title'
  readonly camera = new THREE.PerspectiveCamera(72, 1, 0.05, 180)
  readonly physics: Physics
  readonly world: World
  readonly player: Player
  readonly portals: Portals
  readonly dummies: Dummies
  yaw = 0
  pitch = 0
  private readonly gunRoot = new THREE.Group()
  private readonly raycaster = new THREE.Raycaster()
  private readonly hitPoint = new THREE.Vector3()
  private nextPortal: 0 | 1 = 0
  private shots = 0
  private time = 0
  private aiming = false
  private shotLine?: THREE.Line
  private shotLineTime = 0

  constructor(private readonly renderer: Renderer, private readonly input: Input, streetModel: THREE.Object3D, gunModel: THREE.Object3D) {
    this.physics = new Physics(-22)
    this.world = new World(this.physics, renderer.shadowMapSize, streetModel)
    this.player = new Player(this.physics, this.world.spawn)
    this.portals = new Portals(this.world.scene)
    this.dummies = new Dummies(this.physics, this.world.scene)
    this.camera.rotation.order = 'YXZ'
    this.camera.fov = 72
    this.world.scene.add(this.camera)
    this.attachGun(gunModel)
    this.camera.position.copy(this.world.spawn).add(new THREE.Vector3(0, 0.63, 0))
  }

  start(): void {
    this.portals.reset()
    this.dummies.clear()
    this.player.teleport(this.world.spawn)
    this.yaw = 0
    this.pitch = 0
    this.nextPortal = 0
    this.shots = 0
    this.mode = 'playing'
    this.input.takeLook()
    this.input.endFrame()
  }

  pause(): void { if (this.mode === 'playing') this.mode = 'paused' }
  resume(): void { if (this.mode === 'paused') { this.mode = 'playing'; this.input.takeLook(); this.input.endFrame() } }
  toTitle(): void { this.mode = 'title'; this.portals.reset(); this.dummies.clear(); this.removeShotLine() }

  setQuality(quality: Quality): void {
    this.renderer.applyQuality(quality)
    const size = this.renderer.shadowMapSize
    this.world.sun.shadow.map?.dispose()
    this.world.sun.shadow.map = null
    this.world.sun.shadow.mapSize.set(size, size)
    this.world.scene.traverse(object => {
      const mesh = object as THREE.Mesh
      for (const material of (Array.isArray(mesh.material) ? mesh.material : mesh.material ? [mesh.material] : [])) material.needsUpdate = true
    })
  }

  step(dt: number): void {
    const spawn = this.input.consume('spawnDummy')
    const fire = this.input.consume('fire')
    if (this.mode !== 'playing') return

    const previous = this.player.position
    const after = this.player.step(dt, { moveX: this.input.move.x, moveY: this.input.move.y, sprint: this.input.held('sprint') }, this.yaw)
    const through = this.portals.cross(previous, after, this.player.velocity, this.yaw)
    if (through) {
      this.player.teleport(through.position, through.velocity)
      this.yaw = through.yaw
    }
    if (spawn) {
      const forward = this.forward()
      this.dummies.spawn(this.player.position, forward)
    }
    if (fire) this.shoot()
    this.physics.step(dt)
    this.shotLineTime = Math.max(0, this.shotLineTime - dt)
    if (this.shotLineTime === 0) this.removeShotLine()
  }

  render(alpha: number, frameSeconds: number): void {
    this.time += frameSeconds
    this.physics.sync(alpha)
    if (this.mode === 'playing' || this.mode === 'paused') {
      if (this.mode === 'playing') {
        const look = this.input.takeLook()
        this.yaw -= look.x
        this.pitch = THREE.MathUtils.clamp(this.pitch - look.y, -1.32, 1.32)
        this.aiming = this.input.held('aim')
      }
      const targetFov = this.aiming ? 52 : 72
      const nextFov = THREE.MathUtils.damp(this.camera.fov, targetFov, 12, frameSeconds)
      if (Math.abs(nextFov - this.camera.fov) > 0.02) {
        this.camera.fov = nextFov
        this.camera.updateProjectionMatrix()
      }
      this.camera.position.copy(this.player.root.position).add(new THREE.Vector3(0, 0.63, 0))
      this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ')
      this.gunRoot.visible = true
      const gunTarget = this.aiming ? new THREE.Vector3(0.08, -0.18, -0.58) : new THREE.Vector3(0.36, -0.31, -0.72)
      this.gunRoot.position.lerp(gunTarget, 1 - Math.exp(-12 * frameSeconds))
    } else {
      const orbit = this.time * 0.08
      this.camera.position.set(Math.sin(orbit) * 2.5, 4.2, 8 + Math.cos(orbit) * 2.5)
      this.camera.lookAt(0, 1.4, -4)
      this.camera.fov = 72
      this.camera.updateProjectionMatrix()
      this.gunRoot.visible = false
      this.aiming = false
    }
    this.world.update(frameSeconds, this.player.root.position)
    this.portals.update(frameSeconds)
    this.renderer.render(this.world.scene, this.camera)
  }

  status(): GameStatus {
    return { dummies: this.dummies.count, portals: this.portals.count, connected: this.portals.connected, aiming: this.aiming, shots: this.shots }
  }

  private forward(): THREE.Vector3 {
    return new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw)).normalize()
  }

  private attachGun(source: THREE.Object3D): void {
    const model = source.clone(true)
    model.updateMatrixWorld(true)
    const box = new THREE.Box3().setFromObject(model)
    const size = box.getSize(new THREE.Vector3())
    const center = box.getCenter(new THREE.Vector3())
    const max = Math.max(size.x, size.y, size.z, 0.001)
    const pivot = new THREE.Group()
    pivot.add(model)
    model.position.sub(center)
    pivot.scale.setScalar(0.72 / max)
    const axis = size.x > size.z && size.x > size.y ? 'x' : size.y > size.z ? 'y' : 'z'
    if (axis === 'x') pivot.rotation.y = Math.PI / 2
    else if (axis === 'y') pivot.rotation.x = -Math.PI / 2
    else pivot.rotation.y = Math.PI
    model.traverse(object => {
      const mesh = object as THREE.Mesh
      if (mesh.isMesh) { mesh.castShadow = true; mesh.frustumCulled = false }
    })
    this.gunRoot.add(pivot)
    this.gunRoot.position.set(0.36, -0.31, -0.72)
    this.camera.add(this.gunRoot)
  }

  private shoot(): void {
    this.shots += 1
    this.camera.updateMatrixWorld(true)
    const direction = this.camera.getWorldDirection(new THREE.Vector3()).normalize()
    this.raycaster.set(this.camera.position, direction)
    this.raycaster.far = 60
    const targets = [...this.world.shotTargets, ...this.dummies.targets]
    const hit = this.raycaster.intersectObjects(targets, true)[0]
    const end = hit?.point ?? this.camera.position.clone().addScaledVector(direction, 24)
    this.hitPoint.copy(end)
    const anchor = hit?.object.userData.portalAnchor as PortalAnchor | undefined
    if (anchor) {
      this.portals.place(this.nextPortal, anchor)
      this.nextPortal = this.nextPortal === 0 ? 1 : 0
    } else {
      const body = this.findBody(hit?.object)
      if (body?.isDynamic()) body.applyImpulse({ x: direction.x * 7, y: direction.y * 7 + 1.1, z: direction.z * 7 }, true)
    }
    this.showShotLine(this.camera.position.clone().addScaledVector(direction, 0.55), end, anchor ? '#49f4dd' : '#ffae5d')
  }

  private findBody(object?: THREE.Object3D): RAPIER.RigidBody | undefined {
    let node = object
    while (node) {
      const body = node.userData.physicsBody as RAPIER.RigidBody | undefined
      if (body) return body
      node = node.parent ?? undefined
    }
    return undefined
  }

  private showShotLine(from: THREE.Vector3, to: THREE.Vector3, color: string): void {
    this.removeShotLine()
    const geometry = new THREE.BufferGeometry().setFromPoints([from, to])
    const material = new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.86 })
    this.shotLine = new THREE.Line(geometry, material)
    this.world.scene.add(this.shotLine)
    this.shotLineTime = 0.075
  }

  private removeShotLine(): void {
    if (!this.shotLine) return
    this.world.scene.remove(this.shotLine)
    this.shotLine.geometry.dispose()
    ;(this.shotLine.material as THREE.Material).dispose()
    this.shotLine = undefined
  }
}
