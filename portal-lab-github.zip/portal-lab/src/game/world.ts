import * as THREE from 'three'
import { RAPIER, type Physics } from '../engine/physics'

const UP = new THREE.Vector3(0, 1, 0)
const FORWARD = new THREE.Vector3(0, 0, 1)

export type PortalAnchor = {
  id: string
  mesh: THREE.Mesh
  center: THREE.Vector3
  normal: THREE.Vector3
  right: THREE.Vector3
  width: number
  height: number
}

/** Offline alien neighborhood built around the generated residential-street GLB. */
export class World {
  readonly scene = new THREE.Scene()
  readonly sun: THREE.DirectionalLight
  readonly spawn = new THREE.Vector3(0, 0.94, 3.2)
  readonly portalAnchors: PortalAnchor[] = []
  readonly shotTargets: THREE.Object3D[] = []
  readonly props: THREE.Object3D[] = []

  constructor(private readonly physics: Physics, shadowMapSize: number, streetModel: THREE.Object3D) {
    this.scene.background = new THREE.Color('#a5c6cb')
    this.scene.fog = new THREE.Fog('#a5c6cb', 80, 210)
    this.scene.add(new THREE.HemisphereLight('#d9f2ff', '#3c4540', 1.35))
    this.sun = new THREE.DirectionalLight('#fff1da', 3.1)
    this.sun.castShadow = true
    this.sun.shadow.mapSize.set(shadowMapSize, shadowMapSize)
    Object.assign(this.sun.shadow.camera, { left: -48, right: 48, top: 48, bottom: -48, near: 1, far: 130 })
    this.sun.shadow.bias = -0.0005
    this.sun.shadow.normalBias = 0.03
    this.scene.add(this.sun, this.sun.target)

    this.makeGround()
    this.makeRoad()
    this.makeHouses()
    this.makeStreetLights()
    this.makeAlienStreet(streetModel)
    this.makePortalFrame('portal-frame-a', new THREE.Vector3(0, 1.45, -10), new THREE.Vector3(0, 0, 1))
    this.makePortalFrame('portal-frame-b', new THREE.Vector3(9, 1.45, 7), new THREE.Vector3(-1, 0, 0))
    this.makeProps()
  }

  update(_dt: number, focus: THREE.Vector3): void {
    this.sun.position.set(focus.x - 22, focus.y + 38, focus.z + 16)
    this.sun.target.position.copy(focus)
  }

  private makeGround(): void {
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(220, 220), new THREE.MeshStandardMaterial({ color: '#697761', roughness: 0.96 }))
    ground.rotation.x = -Math.PI / 2
    ground.position.y = -0.04
    ground.receiveShadow = true
    this.scene.add(ground)
    this.physics.addStaticBox(new THREE.Vector3(0, -0.29, 0), new THREE.Vector3(220, 0.5, 220), undefined, 0.9)
  }

  private makeRoad(): void {
    const asphalt = new THREE.MeshStandardMaterial({ color: '#343c40', roughness: 0.92, metalness: 0.02 })
    const concrete = new THREE.MeshStandardMaterial({ color: '#9ca6a1', roughness: 0.87 })
    const paint = new THREE.MeshStandardMaterial({ color: '#e7ce91', roughness: 0.8 })
    const road = new THREE.Mesh(new THREE.BoxGeometry(8.4, 0.06, 150), asphalt)
    road.position.set(0, -0.005, -8)
    road.receiveShadow = true
    this.scene.add(road)
    for (const side of [-1, 1]) {
      const walk = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.18, 150), concrete)
      walk.position.set(side * 5.15, 0.025, -8)
      walk.receiveShadow = true
      walk.castShadow = true
      this.scene.add(walk)
      this.physics.addStaticBox(walk.position, new THREE.Vector3(2.1, 0.18, 150), undefined, 0.9)
      const edge = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.012, 150), paint)
      edge.position.set(side * 3.8, 0.031, -8)
      this.scene.add(edge)
    }
    for (let z = -78; z < 65; z += 7) {
      const dash = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.012, 3.1), paint)
      dash.position.set(0, 0.032, z)
      this.scene.add(dash)
    }
  }

  private makeHouses(): void {
    const wallMats = ['#d2ad82', '#b6c7b4', '#c8bd9b', '#93b4b5'].map(color => new THREE.MeshStandardMaterial({ color, roughness: 0.88, metalness: 0.02 }))
    const roofMats = ['#414950', '#675a52', '#515c61'].map(color => new THREE.MeshStandardMaterial({ color, roughness: 0.86, metalness: 0.05 }))
    const glass = new THREE.MeshStandardMaterial({ color: '#94d4d5', roughness: 0.24, metalness: 0.18, emissive: '#16464a', emissiveIntensity: 0.16 })
    const doorMat = new THREE.MeshStandardMaterial({ color: '#5d4b3b', roughness: 0.75 })
    const concrete = new THREE.MeshStandardMaterial({ color: '#a4aaa3', roughness: 0.88 })
    const positions: Array<[number, number]> = [[-13, -31], [13, -31], [-14, -2], [14, -2], [-13, 28], [14, 28]]
    positions.forEach(([x, z], i) => {
      const width = i % 2 ? 6.8 : 6.2
      const depth = i % 2 ? 5.8 : 5.3
      const height = 3.5 + (i % 3) * 0.35
      const base = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), wallMats[i % wallMats.length])
      base.position.set(x, height / 2, z)
      base.castShadow = true
      base.receiveShadow = true
      this.scene.add(base)
      this.physics.addStaticBox(base.position, new THREE.Vector3(width, height, depth), undefined, 0.7)
      const roof = new THREE.Mesh(new THREE.ConeGeometry(width * 0.76, 1.9, 4), roofMats[i % roofMats.length])
      roof.rotation.y = Math.PI / 4
      roof.position.set(x, height + 0.9, z)
      roof.castShadow = true
      roof.receiveShadow = true
      this.scene.add(roof)

      const frontZ = z + depth / 2 + 0.035
      for (const side of [-1, 1]) {
        const windowMesh = new THREE.Mesh(new THREE.BoxGeometry(1.05, 1, 0.08), glass)
        windowMesh.position.set(x + side * width * 0.28, 2.05, frontZ)
        this.scene.add(windowMesh)
        const sill = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.11, 0.17), concrete)
        sill.position.set(x + side * width * 0.28, 1.51, frontZ + 0.02)
        this.scene.add(sill)
      }
      const door = new THREE.Mesh(new THREE.BoxGeometry(0.9, 2.05, 0.1), doorMat)
      door.position.set(x, 1.03, frontZ + 0.02)
      this.scene.add(door)
      const porch = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.14, 1.3), concrete)
      porch.position.set(x, 0.08, z + depth / 2 + 0.6)
      this.scene.add(porch)
    })
  }

  private makeStreetLights(): void {
    const poleMat = new THREE.MeshStandardMaterial({ color: '#59666a', roughness: 0.42, metalness: 0.7 })
    const bulbMat = new THREE.MeshStandardMaterial({ color: '#caffbb', emissive: '#a9ff80', emissiveIntensity: 1.25, roughness: 0.28 })
    for (let z = -34; z <= 26; z += 15) {
      for (const side of [-1, 1]) {
        const x = side * 6.9
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.11, 4.4, 10), poleMat)
        pole.position.set(x, 2.2, z)
        pole.castShadow = true
        this.scene.add(pole)
        const arm = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.1, 0.1), poleMat)
        arm.position.set(x - side * 0.35, 4.25, z)
        this.scene.add(arm)
        const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 8), bulbMat)
        bulb.position.set(x - side * 0.75, 4.13, z)
        this.scene.add(bulb)
      }
    }
  }

  private makeAlienStreet(streetModel: THREE.Object3D): void {
    const model = streetModel.clone(true)
    model.updateMatrixWorld(true)
    const size = new THREE.Box3().setFromObject(model).getSize(new THREE.Vector3())
    model.scale.setScalar(19 / Math.max(size.x, size.z, 0.01))
    model.updateMatrixWorld(true)
    const bounds = new THREE.Box3().setFromObject(model)
    model.position.set(26, -bounds.min.y, -7)
    model.traverse(object => {
      const mesh = object as THREE.Mesh
      if (mesh.isMesh) { mesh.castShadow = true; mesh.receiveShadow = true }
    })
    this.scene.add(model)
  }

  private makePortalFrame(id: string, center: THREE.Vector3, normal: THREE.Vector3): void {
    const n = normal.clone().normalize()
    const right = new THREE.Vector3().crossVectors(UP, n).normalize()
    const rotation = new THREE.Quaternion().setFromUnitVectors(FORWARD, n)
    const outerWidth = 4
    const outerHeight = 3.2
    const openingWidth = 1.75
    const openingHeight = 2.9
    const sideWidth = (outerWidth - openingWidth) / 2
    const railHeight = (outerHeight - openingHeight) / 2
    const metal = new THREE.MeshStandardMaterial({ color: '#363e43', roughness: 0.34, metalness: 0.72 })
    const edge = new THREE.MeshStandardMaterial({ color: '#596a70', roughness: 0.4, metalness: 0.68 })
    const accent = new THREE.MeshStandardMaterial({ color: '#50e4b0', emissive: '#1bb58d', emissiveIntensity: 0.55, roughness: 0.34, metalness: 0.28 })
    const frame = new THREE.Group()
    frame.position.copy(center)
    frame.quaternion.copy(rotation)

    const addPart = (x: number, y: number, z: number, w: number, h: number, d: number, material: THREE.Material, collider: boolean) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material)
      mesh.position.set(x, y, z)
      mesh.castShadow = true
      mesh.receiveShadow = true
      frame.add(mesh)
      if (collider) {
        const worldPos = center.clone().add(new THREE.Vector3(x, y, z).applyQuaternion(rotation))
        this.physics.addStaticBox(worldPos, new THREE.Vector3(w, h, d), rotation, 0.72)
      }
    }
    for (const side of [-1, 1]) {
      const x = side * (openingWidth / 2 + sideWidth / 2)
      addPart(x, 0, 0, sideWidth, outerHeight, 0.46, metal, true)
      addPart(x - side * (sideWidth / 2 - 0.08), 0, 0.245, 0.08, outerHeight - 0.12, 0.04, accent, false)
    }
    for (const side of [-1, 1]) addPart(0, side * (openingHeight / 2 + railHeight / 2), 0, openingWidth, railHeight, 0.46, edge, side > 0)
    for (const side of [-1, 1]) {
      const bolt = new THREE.Mesh(new THREE.SphereGeometry(0.09, 12, 8), accent)
      bolt.position.set(side * (outerWidth / 2 - 0.25), 1.25, 0.27)
      frame.add(bolt)
    }
    const target = new THREE.Mesh(
      new THREE.PlaneGeometry(openingWidth, openingHeight),
      new THREE.MeshBasicMaterial({ colorWrite: false, transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide }),
    )
    target.position.z = 0.245
    frame.add(target)
    this.scene.add(frame)

    const anchor: PortalAnchor = { id, mesh: target, center: center.clone().addScaledVector(n, 0.245), normal: n, right, width: openingWidth, height: openingHeight }
    target.userData.portalAnchor = anchor
    this.portalAnchors.push(anchor)
    this.shotTargets.push(target)
  }

  private makeProps(): void {
    const mats = [
      new THREE.MeshStandardMaterial({ color: '#66716d', roughness: 0.7, metalness: 0.26 }),
      new THREE.MeshStandardMaterial({ color: '#746b59', roughness: 0.9, metalness: 0.02 }),
      new THREE.MeshStandardMaterial({ color: '#425661', roughness: 0.68, metalness: 0.35 }),
    ]
    const positions: Array<[number, number]> = [[-2.4, -1.5], [2.1, -4.4], [-1.8, -18], [2.3, 15], [-3, 26], [3.2, -27]]
    positions.forEach(([x, z], index) => {
      const size = index % 2 ? 0.68 : 0.88
      const root = new THREE.Mesh(new THREE.BoxGeometry(size, size, size), mats[index % mats.length])
      root.position.set(x, size / 2 + 0.04, z)
      root.rotation.y = index * 0.43
      root.castShadow = true
      root.receiveShadow = true
      const body = this.physics.addDynamic(root, RAPIER.ColliderDesc.cuboid(size / 2, size / 2, size / 2).setFriction(0.68), 0.18)
      root.userData.physicsBody = body
      this.scene.add(root)
      this.props.push(root)
      this.shotTargets.push(root)
    })
  }
}
