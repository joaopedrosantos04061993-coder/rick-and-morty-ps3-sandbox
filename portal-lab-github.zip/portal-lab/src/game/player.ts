import * as THREE from 'three'
import { RAPIER, type Physics } from '../engine/physics'

export type PlayerIntent = { moveX: number; moveY: number; sprint: boolean }
const UP = new THREE.Vector3(0, 1, 0)
const RADIUS = 0.28
const HALF_HEIGHT = 0.62

/** First-person capsule controller; the capsule is invisible and only owns collision/movement. */
export class Player {
  readonly root = new THREE.Group()
  readonly body: RAPIER.RigidBody
  readonly collider: RAPIER.Collider
  readonly velocity = new THREE.Vector3()
  grounded = false
  private readonly controller: RAPIER.KinematicCharacterController

  constructor(private readonly physics: Physics, readonly spawn: THREE.Vector3) {
    this.body = physics.world.createRigidBody(RAPIER.RigidBodyDesc.kinematicPositionBased().setTranslation(spawn.x, spawn.y, spawn.z))
    this.collider = physics.world.createCollider(
      RAPIER.ColliderDesc.capsule(HALF_HEIGHT, RADIUS).setFriction(0),
      this.body,
    )
    this.controller = physics.world.createCharacterController(0.02)
    this.controller.enableAutostep(0.36, 0.22, false)
    this.controller.enableSnapToGround(0.28)
    this.controller.setMaxSlopeClimbAngle(THREE.MathUtils.degToRad(48))
    this.controller.setMinSlopeSlideAngle(THREE.MathUtils.degToRad(35))
    this.controller.setApplyImpulsesToDynamicBodies(true)
    this.root.position.copy(spawn)
    physics.bind(this.body, this.root)
  }

  get position(): THREE.Vector3 {
    const p = this.body.translation()
    return new THREE.Vector3(p.x, p.y, p.z)
  }

  step(dt: number, intent: PlayerIntent, cameraYaw: number): THREE.Vector3 {
    const forward = new THREE.Vector3(-Math.sin(cameraYaw), 0, -Math.cos(cameraYaw))
    const right = new THREE.Vector3().crossVectors(forward, UP)
    const wish = new THREE.Vector3().addScaledVector(right, intent.moveX).addScaledVector(forward, intent.moveY)
    const amount = Math.min(1, wish.length())
    if (amount > 0.01) wish.normalize()

    const speed = intent.sprint ? 7 : 4.6
    const target = wish.clone().multiplyScalar(speed * amount)
    const blend = 1 - Math.exp(-(this.grounded ? 12 : 4.5) * dt)
    this.velocity.x = THREE.MathUtils.lerp(this.velocity.x, target.x, blend)
    this.velocity.z = THREE.MathUtils.lerp(this.velocity.z, target.z, blend)
    if (this.grounded && this.velocity.y < 0) this.velocity.y = -0.6
    else this.velocity.y = Math.max(-28, this.velocity.y - 22 * dt)

    const desired = this.velocity.clone().multiplyScalar(dt)
    this.controller.computeColliderMovement(this.collider, desired)
    const moved = this.controller.computedMovement()
    this.grounded = this.controller.computedGrounded()
    if (Math.abs(moved.x - desired.x) > 1e-3) this.velocity.x = 0
    if (Math.abs(moved.z - desired.z) > 1e-3) this.velocity.z = 0
    if (moved.y > desired.y + 1e-3 || (this.grounded && this.velocity.y < 0)) this.velocity.y = 0

    const current = this.body.translation()
    const next = new THREE.Vector3(current.x + moved.x, current.y + moved.y, current.z + moved.z)
    this.body.setNextKinematicTranslation({ x: next.x, y: next.y, z: next.z })
    return next
  }

  teleport(position: THREE.Vector3, velocity?: THREE.Vector3): void {
    this.body.setTranslation({ x: position.x, y: position.y, z: position.z }, true)
    this.body.setNextKinematicTranslation({ x: position.x, y: position.y, z: position.z })
    this.velocity.copy(velocity ?? new THREE.Vector3())
    this.root.position.copy(position)
    this.physics.snap(this.body)
  }

  static get radius(): number { return RADIUS }
}
