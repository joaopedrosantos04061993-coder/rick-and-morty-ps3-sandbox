import type { Audio } from '../engine/audio'
import type { I18n } from '../engine/i18n'
import type { Input } from '../engine/input'
import type { GameStatus } from '../game/game'
import type { Quality, SaveData, SaveStore } from '../engine/save'

export type Screen = 'boot' | 'title' | 'hud' | 'pause' | 'options' | 'exit'
export type UiActions = {
  play(): void
  resume(): void
  quit(): void
  exit(): void
  settings(patch: Partial<SaveData>): void
}

/** DOM overlay for title, control help, options, simulated exit, pause and in-game HUD. */
export class Ui {
  screen: Screen = 'boot'
  private readonly root: HTMLElement
  private stack: Screen[] = []
  private navRepeat = 0
  private lastMethod = ''

  constructor(
    private readonly i18n: I18n,
    private readonly save: SaveStore,
    private readonly audio: Audio,
    private readonly input: Input,
    private readonly actions: UiActions,
    menuImageUrl: string,
    faviconUrl: string,
  ) {
    this.root = document.getElementById('ui')!
    this.root.innerHTML = this.template(menuImageUrl, faviconUrl)
    this.root.addEventListener('click', event => this.onClick(event))
    this.root.addEventListener('input', event => this.onInput(event))
    window.addEventListener('keydown', event => this.onKey(event))
    i18n.onChange(() => this.translate())
    this.translate()
    this.refreshSettings()
  }

  show(screen: Screen): void { this.stack = []; this.setScreen(screen) }
  push(screen: Screen): void { this.stack.push(this.screen); this.setScreen(screen) }

  back(): void {
    const previous = this.stack.pop()
    if (previous) this.setScreen(previous)
    else if (this.screen === 'pause') this.actions.resume()
  }

  setBootProgress(progress: number): void {
    const bar = this.root.querySelector<HTMLElement>('.boot-bar i')
    if (bar) bar.style.transform = `scaleX(${Math.max(0.04, Math.min(1, progress))})`
  }

  showBootError(_error: unknown): void {
    const label = this.root.querySelector<HTMLElement>('.boot-label')
    if (label) label.textContent = this.i18n.t('boot.error')
    const retry = this.root.querySelector<HTMLButtonElement>('.boot-retry')
    if (retry) retry.classList.remove('is-hidden')
  }

  updateHud(status: GameStatus): void {
    this.setText('[data-slot="dummies"]', this.i18n.t('hud.dummies', { count: status.dummies }))
    this.setText('[data-slot="portals"]', this.i18n.t('hud.portals', { count: status.portals }))
    this.setText('[data-slot="portal-state"]', this.i18n.t(status.connected ? 'hud.linked' : 'hud.unlinked'))
    this.root.dataset.method = this.input.method
    const reticle = this.root.querySelector<HTMLElement>('.reticle')
    reticle?.classList.toggle('is-aiming', status.aiming)
    this.root.querySelector<HTMLElement>('.reticle-label')!.textContent = this.i18n.t(status.aiming ? 'hud.reticleAim' : 'hud.reticleReady')
    this.setText('[data-slot="shots"]', this.i18n.t('hud.shots', { count: status.shots }))
  }

  refreshSettings(): void {
    const data = this.save.data
    for (const input of this.root.querySelectorAll<HTMLInputElement>('input[type="range"]')) {
      input.value = String(data[input.name as 'musicVolume' | 'sfxVolume' | 'sensitivity'])
      this.updateRangeFill(input)
    }
    for (const button of this.root.querySelectorAll<HTMLButtonElement>('.toggle')) {
      const key = button.dataset.setting as 'muted' | 'invertY'
      const on = data[key]
      button.setAttribute('aria-pressed', String(on))
      button.querySelector('span')!.textContent = this.i18n.t(on ? 'options.on' : 'options.off')
    }
    for (const button of this.root.querySelectorAll<HTMLButtonElement>('.seg button')) {
      button.setAttribute('aria-pressed', String(button.dataset.value === data.quality))
    }
    this.translate()
  }

  frame(frameSeconds: number): void {
    if (this.input.method !== this.lastMethod) {
      this.lastMethod = this.input.method
      this.root.dataset.method = this.input.method
    }
    if (this.screen === 'hud' || this.screen === 'boot') return
    if (this.input.method !== 'gamepad') {
      this.input.consume('confirm')
      this.input.consume('back')
      return
    }
    const y = this.input.navigation.y
    const x = this.input.navigation.x
    this.navRepeat = Math.max(0, this.navRepeat - frameSeconds)
    const active = document.activeElement as HTMLElement | null
    if (Math.abs(y) > 0.6 && this.navRepeat <= 0) {
      this.moveFocus(y < 0 ? 1 : -1)
      this.navRepeat = 0.22
    } else if (Math.abs(x) > 0.6 && this.navRepeat <= 0 && active?.matches('input[type="range"]')) {
      const range = active as HTMLInputElement
      range.value = String(Number(range.value) + Math.sign(x) * Number(range.step || 0.1))
      range.dispatchEvent(new Event('input', { bubbles: true }))
      this.navRepeat = 0.12
    } else if (Math.abs(x) > 0.6 && this.navRepeat <= 0 && active?.parentElement?.matches('.seg')) {
      const next = (Math.sign(x) > 0 ? active.nextElementSibling : active.previousElementSibling) as HTMLElement | null
      next?.focus()
      this.navRepeat = 0.22
    } else if (Math.abs(y) < 0.3 && Math.abs(x) < 0.3) {
      this.navRepeat = 0
    }
    if (this.input.consume('confirm')) (document.activeElement as HTMLElement | null)?.click()
    if (this.input.consume('back') && this.screen !== 'title') this.back()
  }

  private setScreen(screen: Screen): void {
    this.screen = screen
    for (const element of this.root.querySelectorAll<HTMLElement>('[data-screen]')) {
      const active = element.dataset.screen === screen || (element.dataset.screen === 'hud' && screen === 'pause')
      element.classList.toggle('is-active', active)
      element.setAttribute('aria-hidden', String(!active))
    }
    this.root.dataset.activeScreen = screen
    requestAnimationFrame(() => {
      const first = this.navItems()[0]
      if (first && this.input.method !== 'touch') first.focus({ preventScroll: true })
      else (document.activeElement as HTMLElement | null)?.blur?.()
    })
  }

  private onClick(event: MouseEvent): void {
    const target = (event.target as HTMLElement).closest<HTMLElement>('[data-action], .toggle, .seg button')
    if (!target) return
    this.audio.unlock()
    if (target.matches('.toggle')) {
      const key = target.dataset.setting as 'muted' | 'invertY'
      this.actions.settings({ [key]: !this.save.data[key] })
      this.refreshSettings()
      this.audio.play('ui')
      return
    }
    if (target.matches('.seg button')) {
      this.actions.settings({ quality: target.dataset.value as Quality })
      this.refreshSettings()
      this.audio.play('ui')
      return
    }
    switch (target.dataset.action) {
      case 'play': this.actions.play(); break
      case 'resume': this.actions.resume(); break
      case 'quit': this.actions.quit(); break
      case 'exit': this.actions.exit(); break
      case 'options': this.push('options'); break
      case 'back': this.back(); break
      case 'ack-exit': this.back(); break
      case 'retry': window.location.reload(); break
      case 'pause': window.dispatchEvent(new CustomEvent('game:pause')); break
    }
    this.audio.play('ui')
  }

  private onInput(event: Event): void {
    const element = event.target as HTMLInputElement
    if (element.type !== 'range') return
    this.updateRangeFill(element)
    this.actions.settings({ [element.name]: Number(element.value) } as Partial<SaveData>)
  }

  private updateRangeFill(input: HTMLInputElement): void {
    const percent = (Number(input.value) - Number(input.min)) / (Number(input.max) - Number(input.min)) * 100
    input.style.setProperty('--fill', `${percent}%`)
  }

  private onKey(event: KeyboardEvent): void {
    if (this.screen === 'hud' || this.screen === 'boot') return
    const typing = (event.target as HTMLElement).matches?.('input[type="text"], input[type="range"]')
    if ((event.code === 'Escape' || (event.code === 'Backspace' && !typing)) && this.screen !== 'title') {
      event.preventDefault()
      this.input.consume('pause')
      this.back()
    } else if (event.code === 'ArrowDown' || event.code === 'ArrowUp') {
      event.preventDefault()
      this.moveFocus(event.code === 'ArrowDown' ? 1 : -1)
    }
  }

  private navItems(): HTMLElement[] {
    const screen = this.root.querySelector<HTMLElement>(`[data-screen="${this.screen}"]`)
    if (!screen) return []
    return [...screen.querySelectorAll<HTMLElement>('[data-nav]')].filter(element => element.offsetParent !== null && !element.closest('.is-hidden'))
  }

  private moveFocus(direction: 1 | -1): void {
    const items = this.navItems()
    if (!items.length) return
    const current = items.indexOf(document.activeElement as HTMLElement)
    items[(current + direction + items.length) % items.length].focus()
  }

  private setText(selector: string, text: string): void {
    const element = this.root.querySelector<HTMLElement>(selector)
    if (element && element.textContent !== text) element.textContent = text
  }

  private translate(): void {
    for (const element of this.root.querySelectorAll<HTMLElement>('[data-i18n]')) element.textContent = this.i18n.t(element.dataset.i18n!)
    for (const element of this.root.querySelectorAll<HTMLElement>('[data-i18n-label]')) element.setAttribute('aria-label', this.i18n.t(element.dataset.i18nLabel!))
    this.root.querySelector<HTMLElement>('.menu-art')?.setAttribute('alt', this.i18n.t('menu.artAlt'))
    document.title = this.i18n.t('game.title')
    this.refreshSettingsLabels()
  }

  private refreshSettingsLabels(): void {
    for (const button of this.root.querySelectorAll<HTMLButtonElement>('.toggle')) {
      button.querySelector('span')!.textContent = this.i18n.t(button.getAttribute('aria-pressed') === 'true' ? 'options.on' : 'options.off')
    }
  }

  private template(menuImageUrl: string, faviconUrl: string): string {
    const range = (name: string, key: string, min: number, max: number, step: number) =>
      `<label class="option-row"><span data-i18n="${key}"></span><input data-nav type="range" name="${name}" min="${min}" max="${max}" step="${step}"></label>`
    const toggle = (setting: string, key: string) =>
      `<div class="option-row"><span data-i18n="${key}"></span><button data-nav class="toggle" data-setting="${setting}" aria-pressed="false"><i></i><span></span></button></div>`
    const quality = (value: Quality, key: string) => `<button data-nav data-value="${value}" data-i18n="${key}"></button>`
    return /* html */ `
<section class="screen screen-boot is-active" data-screen="boot">
  <img class="boot-icon" src="${faviconUrl}" alt="">
  <h1 data-i18n="game.title"></h1><div class="boot-bar"><i></i></div>
  <p class="boot-label" data-i18n="boot.loading"></p>
  <button class="btn boot-retry is-hidden" data-action="retry"><span data-i18n="boot.retry"></span></button>
</section>
<section class="screen screen-title" data-screen="title">
  <img class="menu-art" src="${menuImageUrl}" alt=""><div class="title-shade"></div>
  <div class="brand-block"><p class="eyebrow" data-i18n="game.fan"></p><h1 data-i18n="game.title"></h1>
    <p class="tagline" data-i18n="game.tagline"></p><nav class="menu">
      <button data-nav class="btn btn-primary" data-action="play"><span data-i18n="menu.play"></span></button>
      <button data-nav class="btn" data-action="options"><span data-i18n="menu.options"></span></button>
      <button data-nav class="btn btn-exit" data-action="exit"><span data-i18n="menu.exit"></span></button>
    </nav>
  </div>
  <footer class="title-footer"><small data-i18n="menu.credit"></small><span data-i18n="menu.target"></span></footer>
</section>
<section class="screen screen-hud" data-screen="hud">
  <div class="hud-top"><div class="hud-label" data-i18n="hud.label"></div><span data-slot="dummies"></span><span data-slot="portals"></span></div>
  <div class="reticle"><i></i><b></b><span class="reticle-label"></span></div>
  <div class="hud-bottom"><span data-slot="portal-state"></span><span class="control-keyboard" data-i18n="hud.keyboard"></span><span class="control-gamepad" data-i18n="hud.gamepad"></span></div>
  <span class="hud-shots" data-slot="shots"></span>
  <button class="pause-button" data-action="pause" data-i18n="hud.pause"></button>
</section>
<section class="screen screen-overlay" data-screen="pause">
  <div class="dialog"><p class="eyebrow" data-i18n="game.title"></p><h2 data-i18n="pause.title"></h2>
    <nav class="menu"><button data-nav class="btn btn-primary" data-action="resume"><span data-i18n="menu.resume"></span></button>
      <button data-nav class="btn" data-action="options"><span data-i18n="menu.options"></span></button>
      <button data-nav class="btn" data-action="quit"><span data-i18n="menu.toTitle"></span></button></nav>
  </div>
</section>
<section class="screen screen-overlay" data-screen="options">
  <div class="dialog dialog-wide"><p class="eyebrow" data-i18n="game.title"></p><h2 data-i18n="options.title"></h2>
    <div class="options-list"><fieldset><legend data-i18n="options.audio"></legend>${range('musicVolume','options.music',0,1,0.05)}${range('sfxVolume','options.effects',0,1,0.05)}${toggle('muted','options.mute')}</fieldset>
      <fieldset><legend data-i18n="options.controls"></legend>${range('sensitivity','options.sensitivity',0.2,3,0.1)}${toggle('invertY','options.invertY')}</fieldset>
      <fieldset><legend data-i18n="options.display"></legend><div class="option-row"><span data-i18n="options.quality"></span><div class="seg">${quality('low','options.low')}${quality('medium','options.medium')}${quality('high','options.high')}</div></div></fieldset>
    </div><button data-nav class="btn" data-action="back"><span data-i18n="menu.back"></span></button>
  </div>
</section>
<section class="screen screen-overlay" data-screen="exit">
  <div class="dialog"><p class="eyebrow" data-i18n="game.title"></p><h2 data-i18n="exit.title"></h2>
    <p class="exit-copy" data-i18n="exit.message"></p><button data-nav class="btn btn-primary" data-action="ack-exit"><span data-i18n="menu.ok"></span></button>
  </div>
</section>`
  }
}
