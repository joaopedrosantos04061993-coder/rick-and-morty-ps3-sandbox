/**
 * Unified input: keyboard + mouse (pointer lock), compatible gamepads and legacy touch controls.
 * Gameplay reads normalized movement, camera look, held aim and edge-triggered actions.
 */
export type Action = 'jump' | 'sprint' | 'dash' | 'pause' | 'confirm' | 'back' | 'interact' | 'aim' | 'fire' | 'spawnDummy'
export type InputMethod = 'keyboard' | 'gamepad' | 'touch'

const KEY_BINDINGS: Record<Action, string[]> = {
  jump: ['Space'],
  sprint: ['ShiftLeft', 'ShiftRight'],
  dash: ['KeyF'],
  pause: ['Escape', 'KeyP'],
  confirm: ['Enter', 'NumpadEnter'],
  back: ['Escape', 'Backspace'],
  interact: ['KeyE'],
  aim: ['ControlLeft', 'ControlRight'],
  fire: ['KeyR'],
  spawnDummy: ['ArrowUp'],
}
const MOVE_KEYS = { up: ['KeyW'], down: ['KeyS'], left: ['KeyA'], right: ['KeyD'] }
// Standard Gamepad API: L2=6, R2=7, D-pad up=12, Start=9, A=0, B=1.
const PAD_BINDINGS: Record<Action, number[]> = {
  jump: [0], sprint: [4], dash: [5], pause: [9], confirm: [0], back: [1], interact: [3], aim: [6], fire: [7], spawnDummy: [12],
}

export class Input {
  /** Movement intent in [-1, 1]: x = strafe right, y = forward. */
  readonly move = { x: 0, y: 0 }
  /** Directional input for menu navigation; d-pad does not move the player. */
  readonly navigation = { x: 0, y: 0 }
  /** Camera look delta accumulated until `takeLook()` (radians-ish units, pre-sensitivity). */
  readonly look = { x: 0, y: 0 }
  method: InputMethod = 'keyboard'
  sensitivity = 1
  invertY = false

  private keys = new Set<string>()
  private held_ = new Set<Action>()
  private pressed_ = new Set<Action>()
  private touchMove = { x: 0, y: 0 }
  private touchButtons = new Set<Action>()
  private mouseAim = false
  private mouseFire = false
  private padPrev: boolean[] = []
  private padIndex = -1
  private padId = ''
  private listeners: Array<() => void> = []

  constructor(private readonly canvas: HTMLCanvasElement) {
    const on = <K extends keyof WindowEventMap>(target: Window | HTMLElement, type: K, fn: (e: WindowEventMap[K]) => void, opts?: AddEventListenerOptions) => {
      target.addEventListener(type, fn as EventListener, opts)
      this.listeners.push(() => target.removeEventListener(type, fn as EventListener, opts))
    }
    on(window, 'keydown', e => {
      if (e.repeat) return
      this.keys.add(e.code)
      this.method = 'keyboard'
      for (const [action, codes] of Object.entries(KEY_BINDINGS) as [Action, string[]][]) {
        if (codes.includes(e.code)) this.pressed_.add(action)
      }
      const typing = (e.target as HTMLElement | null)?.matches?.('input, textarea')
      if (!typing && (e.code === 'Space' || e.code.startsWith('Arrow'))) e.preventDefault()
    })
    on(window, 'keyup', e => this.keys.delete(e.code))
    on(window, 'blur', () => {
      this.keys.clear()
      this.mouseAim = false
      this.mouseFire = false
    })
    on(window, 'gamepaddisconnected', e => {
      if (e.gamepad.index === this.padIndex) this.resetPad()
    })
    on(window, 'mousedown', e => {
      if (document.pointerLockElement !== canvas) return
      if (e.button === 0) {
        this.mouseFire = true
        this.pressed_.add('fire')
        this.method = 'keyboard'
      } else if (e.button === 2) {
        this.mouseAim = true
        this.method = 'keyboard'
      }
    })
    on(window, 'mouseup', e => {
      if (e.button === 0) this.mouseFire = false
      if (e.button === 2) this.mouseAim = false
    })
    on(window, 'contextmenu', e => {
      if (document.pointerLockElement === canvas) e.preventDefault()
    })
    on(window, 'mousemove', e => {
      if (document.pointerLockElement !== canvas) return
      this.look.x += e.movementX * 0.0022
      this.look.y += e.movementY * 0.0022
    })
  }

  lockPointer(): void {
    if (this.method !== 'touch' && document.pointerLockElement !== this.canvas) {
      this.canvas.requestPointerLock?.()?.catch?.(() => undefined)
    }
  }

  unlockPointer(): void {
    if (document.pointerLockElement) document.exitPointerLock()
  }

  /** Touch methods remain available to the starter's unused touch adapter. */
  setTouchMove(x: number, y: number): void {
    this.method = 'touch'
    this.touchMove.x = x
    this.touchMove.y = y
  }

  addTouchLook(dx: number, dy: number): void {
    this.method = 'touch'
    this.look.x += dx * 0.006
    this.look.y += dy * 0.006
  }

  setTouchButton(action: Action, down: boolean): void {
    this.method = 'touch'
    if (down && !this.touchButtons.has(action)) this.pressed_.add(action)
    if (down) this.touchButtons.add(action)
    else this.touchButtons.delete(action)
  }

  private resetPad(): void {
    this.padPrev = []
    this.padIndex = -1
    this.padId = ''
    this.navigation.x = this.navigation.y = 0
  }

  update(frameSeconds = 1 / 60): void {
    const down = (codes: string[]) => codes.some(code => this.keys.has(code))
    let x = (down(MOVE_KEYS.right) ? 1 : 0) - (down(MOVE_KEYS.left) ? 1 : 0)
    let y = (down(MOVE_KEYS.up) ? 1 : 0) - (down(MOVE_KEYS.down) ? 1 : 0)
    this.held_.clear()
    for (const [action, codes] of Object.entries(KEY_BINDINGS) as [Action, string[]][]) {
      if (down(codes)) this.held_.add(action)
    }
    for (const action of this.touchButtons) this.held_.add(action)
    if (this.mouseAim) this.held_.add('aim')
    if (this.mouseFire) this.held_.add('fire')
    if (this.touchMove.x !== 0 || this.touchMove.y !== 0) {
      x = this.touchMove.x
      y = this.touchMove.y
    }

    const pad = navigator.getGamepads?.().find(p => p && p.connected)
    if (pad) {
      if (pad.index !== this.padIndex || pad.id !== this.padId) this.padPrev = []
      this.padIndex = pad.index
      this.padId = pad.id
      const dead = (v: number) => Math.abs(v) < 0.18 ? 0 : v
      const lx = dead(pad.axes[0] ?? 0)
      const ly = dead(pad.axes[1] ?? 0)
      const rx = dead(pad.axes[2] ?? 0)
      const ry = dead(pad.axes[3] ?? 0)
      const buttonDown = (i: number) => {
        const b = pad.buttons[i]
        return Boolean(b && (b.pressed || b.value > 0.55))
      }
      const padActive = lx !== 0 || ly !== 0 || rx !== 0 || ry !== 0 || pad.buttons.some(b => b.pressed)
      if (padActive) this.method = 'gamepad'
      if (lx !== 0 || ly !== 0) {
        x = lx
        y = -ly
      }
      const dx = (buttonDown(15) ? 1 : 0) - (buttonDown(14) ? 1 : 0)
      const dy = (buttonDown(12) ? 1 : 0) - (buttonDown(13) ? 1 : 0)
      this.navigation.x = dx || lx
      this.navigation.y = dy || -ly
      this.look.x += rx * 2.7 * frameSeconds
      this.look.y += ry * 2.7 * frameSeconds
      for (const [action, buttons] of Object.entries(PAD_BINDINGS) as [Action, number[]][]) {
        const isDown = buttons.some(buttonDown)
        if (isDown) this.held_.add(action)
        if (buttons.some(i => buttonDown(i) && !this.padPrev[i])) this.pressed_.add(action)
      }
      this.padPrev = pad.buttons.map((_, i) => buttonDown(i))
    } else {
      this.resetPad()
    }

    const len = Math.hypot(x, y)
    this.move.x = len > 1 ? x / len : x
    this.move.y = len > 1 ? y / len : y
    if (!pad) {
      this.navigation.x = this.move.x
      this.navigation.y = this.move.y
    }
  }

  held(action: Action): boolean { return this.held_.has(action) }
  pressed(action: Action): boolean { return this.pressed_.has(action) }
  consume(action: Action): boolean { return this.pressed_.delete(action) }

  takeLook(): { x: number; y: number } {
    const out = { x: this.look.x * this.sensitivity, y: this.look.y * this.sensitivity * (this.invertY ? -1 : 1) }
    this.look.x = 0
    this.look.y = 0
    return out
  }

  endFrame(): void { this.pressed_.clear() }

  dispose(): void {
    for (const off of this.listeners) off()
    this.listeners = []
  }
}
