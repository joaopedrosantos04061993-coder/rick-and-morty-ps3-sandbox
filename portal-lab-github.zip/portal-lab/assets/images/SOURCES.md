# Origem da imagem do menu

`rick_and_morty_menu.jpg` é a arte promocional horizontal de *Rick and Morty: The Anime* exibida junto da matéria “Rick and Morty: The Anime to Air Both Japanese and English Dub Releases”, publicada por ComicBook.com: https://comicbook.com/anime/news/rick-and-morty-anime-release-date-english-dub/ (consulta em 20 nov. 2026). O arquivo tem 1024 × 576 px e foi copiado da imagem de resultado de busca para uso como fundo do menu deste protótipo.

A página descreve a imagem como arte-chave promocional; a titularidade dos personagens e da arte permanece com seus respectivos detentores. Esta nota não afirma que o uso seja licenciado.
