import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import * as THREE from 'three'
import { Portals } from '../src/game/portals'
import type { PortalAnchor } from '../src/game/world'
const up = new THREE.Vector3(0, 1, 0)
function anchor(id: string, center: THREE.Vector3, normal: THREE.Vector3): PortalAnchor {
  const direction = normal.clone().normalize()
  return {
    id,
    mesh: new THREE.Mesh(new THREE.PlaneGeometry(2, 3), new THREE.MeshBasicMaterial()),
    center,
    normal: direction,
    right: new THREE.Vector3().crossVectors(up, direction).normalize(),
    width: 2,
    height: 3,
  }
}
let portals: Portals
let scene: THREE.Scene
function connect(): { a: PortalAnchor; b: PortalAnchor } {
  const a = anchor('north', new THREE.Vector3(0, 1.45, 0), new THREE.Vector3(0, 0, 1))
  const b = anchor('east', new THREE.Vector3(10, 1.45, 0), new THREE.Vector3(1, 0, 0))
  portals.place(0, a); portals.place(1, b)
  return { a, b }
}
afterEach(() => portals?.reset())
beforeEach(() => { scene = new THREE.Scene(); portals = new Portals(scene) })
describe('linked portals', () => {
  it('requires both endpoints and transports position, velocity and heading from A to B', () => {
    const a = anchor('north', new THREE.Vector3(0, 1.45, 0), new THREE.Vector3(0, 0, 1))
    portals.place(0, a)
    expect(portals.connected).toBe(false)
    expect(portals.cross(new THREE.Vector3(0, 1.45, 0.2), new THREE.Vector3(0, 1.45, -0.2), new THREE.Vector3(0, 0, -4), 0)).toBeNull()
    const b = anchor('east', new THREE.Vector3(10, 1.45, 0), new THREE.Vector3(1, 0, 0))
    portals.place(1, b)
    const result = portals.cross(
      new THREE.Vector3(0, 1.45, 0.2), new THREE.Vector3(0, 1.45, -0.2), new THREE.Vector3(0, 0, -4), 0,
    )
    expect(result).not.toBeNull()
    expect(result!.position.x).toBeCloseTo(10.62)
    expect(result!.velocity.x).toBeCloseTo(4)
    expect(result!.yaw).toBeCloseTo(-Math.PI / 2)
  })
  it('transports through B back to A and rejects crossings outside the aperture', () => {
    connect()
    const back = portals.cross(
      new THREE.Vector3(10.2, 1.45, 0), new THREE.Vector3(9.8, 1.45, 0), new THREE.Vector3(-4, 0, 0), 0,
    )
    expect(back).not.toBeNull()
    expect(back!.position.z).toBeCloseTo(0.62)
    expect(back!.velocity.z).toBeCloseTo(4)
    const outside = portals.cross(
      new THREE.Vector3(0.8, 1.45, 0.2), new THREE.Vector3(0.8, 1.45, -0.2), new THREE.Vector3(0, 0, -4), 0,
    )
    expect(outside).toBeNull()
  })
  it('replaces a portal cleanly and can reset both endpoints', () => {
    const { a, b } = connect()
    portals.place(0, anchor('replacement', new THREE.Vector3(0, 1.45, -5), new THREE.Vector3(0, 0, 1)))
    expect(portals.connected).toBe(true)
    expect(scene.children).toHaveLength(2)
    portals.reset()
    expect(portals.count).toBe(0)
    expect(portals.connected).toBe(false)
    expect(scene.children).toHaveLength(0)
    expect(a.id).not.toBe(b.id)
  })
})
