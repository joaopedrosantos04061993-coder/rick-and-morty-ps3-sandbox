import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { Input } from '../src/engine/input'
let listeners: Map<string, Set<(event: any) => void>>
let pads: Array<Gamepad | null>
let input: Input
const canvas = {} as HTMLCanvasElement
function pad(index = 0): Gamepad {
  return { index, id: `pad-${index}`, connected: true, mapping: 'standard', axes: [0, 0, 0, 0],
    buttons: Array.from({ length: 17 }, () => ({ pressed: false, touched: false, value: 0 })) } as unknown as Gamepad
}
function button(p: Gamepad, index: number, down: boolean): void {
  (p.buttons as GamepadButton[])[index] = { pressed: down, touched: down, value: down ? 1 : 0 }
}
function emit(type: string, event: any = {}): void { for (const listener of listeners.get(type) ?? []) listener(event) }
function key(type: string, code: string, typing = false): void {
  emit(type, { code, repeat: false, target: { matches: () => typing }, preventDefault: vi.fn() })
}
beforeEach(() => {
  listeners = new Map(); pads = [pad()]
  vi.stubGlobal('window', {
    addEventListener(type: string, listener: (event: any) => void) {
      if (!listeners.has(type)) listeners.set(type, new Set())
      listeners.get(type)!.add(listener)
    },
    removeEventListener(type: string, listener: (event: any) => void) { listeners.get(type)?.delete(listener) },
  })
  vi.stubGlobal('document', { pointerLockElement: null })
  vi.stubGlobal('navigator', { getGamepads: () => pads })
  input = new Input(canvas)
})
afterEach(() => { input.dispose(); vi.restoreAllMocks(); vi.unstubAllGlobals() })
describe('FPS gamepad controls', () => {
  it('maps D-pad up to a one-shot dummy spawn, not player movement', () => {
    const p = pads[0]!
    button(p, 12, true); input.update()
    expect(input.method).toBe('gamepad')
    expect(input.move).toEqual({ x: 0, y: 0 })
    expect(input.navigation.y).toBe(1)
    expect(input.consume('spawnDummy')).toBe(true)
    input.update(); expect(input.consume('spawnDummy')).toBe(false)
    button(p, 12, false); input.update()
    button(p, 12, true); input.update()
    expect(input.consume('spawnDummy')).toBe(true)
  })
  it('maps L2 to held aim and R2 to a single fire press', () => {
    const p = pads[0]!
    button(p, 6, true); button(p, 7, true); input.update()
    expect(input.held('aim')).toBe(true)
    expect(input.held('fire')).toBe(true)
    expect(input.consume('fire')).toBe(true)
    input.update(); expect(input.consume('fire')).toBe(false)
    button(p, 6, false); button(p, 7, false); input.update()
    expect(input.held('aim')).toBe(false)
    button(p, 7, true); input.update(); expect(input.consume('fire')).toBe(true)
  })
  it('uses the left stick to move and right stick to look with a dead zone', () => {
    const axes = pads[0]!.axes as number[]
    axes[0] = 0.17; input.update(); expect(input.move.x).toBe(0)
    axes[0] = 0.6; axes[1] = -0.8; input.update()
    expect(input.move).toEqual({ x: 0.6, y: 0.8 })
    axes[0] = 1; axes[1] = -1; input.update()
    expect(input.move.x).toBeCloseTo(Math.SQRT1_2)
    expect(input.move.y).toBeCloseTo(Math.SQRT1_2)
    axes[2] = 1; axes[3] = -1; input.update(1 / 30)
    expect(input.takeLook().x).toBeCloseTo(0.09)
    expect(input.takeLook().x).toBe(0)
  })
  it('keeps pause, confirm and back on the standard gamepad controls', () => {
    const p = pads[0]!
    for (const index of [0, 1, 9]) button(p, index, true)
    input.update()
    for (const action of ['pause', 'confirm', 'back'] as const) {
      expect(input.consume(action)).toBe(true)
      expect(input.consume(action)).toBe(false)
    }
  })
})
describe('keyboard and mouse FPS controls', () => {
  it('maps WASD, ArrowUp, right-mouse aim and left-mouse fire', () => {
    pads = []
    key('keydown', 'KeyW'); key('keydown', 'KeyD'); key('keydown', 'ArrowUp')
    input.update()
    expect(input.move.x).toBeCloseTo(Math.SQRT1_2)
    expect(input.move.y).toBeCloseTo(Math.SQRT1_2)
    expect(input.consume('spawnDummy')).toBe(true)
    key('keyup', 'KeyW'); key('keyup', 'KeyD'); key('keyup', 'ArrowUp'); input.update()
    expect(input.move).toEqual({ x: 0, y: 0 })
    Object.defineProperty(document, 'pointerLockElement', { configurable: true, value: canvas })
    emit('mousedown', { button: 2 }); emit('mousedown', { button: 0 }); input.update()
    expect(input.held('aim')).toBe(true)
    expect(input.held('fire')).toBe(true)
    expect(input.consume('fire')).toBe(true)
  })
  it('applies sensitivity and vertical look inversion', () => {
    pads = []; input.sensitivity = 2; input.invertY = true
    input.addTouchLook(10, 20); input.update(1 / 30)
    const look = input.takeLook()
    expect(look.x).toBeCloseTo(0.12)
    expect(look.y).toBeCloseTo(-0.24)
    const remainder = input.takeLook()
    expect(remainder.x).toBe(0)
    expect(Math.abs(remainder.y)).toBe(0)
  })
  it('clears held pad state when the selected controller disconnects', () => {
    button(pads[0]!, 6, true); input.update(); expect(input.held('aim')).toBe(true)
    emit('gamepaddisconnected', { gamepad: pads[0] }); pads = []; input.update()
    expect(input.held('aim')).toBe(false)
    pads = [pad()]; button(pads[0]!, 6, true); input.update()
    expect(input.held('aim')).toBe(true)
  })
})
